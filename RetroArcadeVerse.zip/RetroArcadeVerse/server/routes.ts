import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameSchema, insertSaveStateSchema, insertGameNotesSchema, insertChatMessageSchema } from "@shared/schema";
import multer from "multer";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  // Consoles
  app.get("/api/consoles", async (req, res) => {
    try {
      const consoles = await storage.getConsoles();
      res.json(consoles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch consoles" });
    }
  });

  // Get single console by ID
  app.get("/api/consoles/:id", async (req, res) => {
    try {
      const consoles = await storage.getConsoles();
      const console = consoles.find(c => c.id === req.params.id);
      if (!console) {
        return res.status(404).json({ message: "Console not found" });
      }
      res.json(console);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch console" });
    }
  });

  // Games
  app.get("/api/games", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: "userId is required" });
      }
      console.log("Fetching games for user:", userId);
      const games = await storage.getGamesByUser(userId);
      console.log("Found games:", games.length);
      res.json(games || []);
    } catch (error) {
      console.error("Error fetching games:", error);
      res.status(500).json({ message: "Failed to fetch games" });
    }
  });

  app.post("/api/games", upload.single("romFile"), async (req: MulterRequest, res) => {
    try {
      console.log("Upload request received:", {
        body: req.body,
        file: req.file ? { name: req.file.originalname, size: req.file.size } : 'No file'
      });

      const { userId, consoleId, title } = req.body;
      const file = req.file;

      if (!file) {
        console.log("No file in request");
        return res.status(400).json({ message: "ROM file is required" });
      }

      if (!userId || !consoleId || !title) {
        console.log("Missing required fields:", { userId, consoleId, title });
        return res.status(400).json({ message: "userId, consoleId, and title are required" });
      }

      const romData = file.buffer.toString('base64');
      
      const gameData = {
        userId,
        consoleId,
        title,
        filename: file.originalname || 'unknown',
        fileSize: file.size,
        romData,
      };

      console.log("Creating game with data:", { ...gameData, romData: '[base64 data]' });

      const validatedData = insertGameSchema.parse(gameData);
      const game = await storage.createGame(validatedData);
      
      console.log("Game created successfully:", game.id);
      res.json(game);
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ 
        message: "Failed to upload game", 
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get("/api/games/:id", async (req, res) => {
    try {
      const game = await storage.getGame(req.params.id);
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch game" });
    }
  });

  app.delete("/api/games/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteGame(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Game not found" });
      }
      res.json({ message: "Game deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete game" });
    }
  });

  // Save States
  app.get("/api/games/:gameId/save-states", async (req, res) => {
    try {
      const saveStates = await storage.getSaveStatesByGame(req.params.gameId);
      res.json(saveStates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch save states" });
    }
  });

  app.post("/api/save-states", async (req, res) => {
    try {
      const validatedData = insertSaveStateSchema.parse(req.body);
      const saveState = await storage.createOrUpdateSaveState(validatedData);
      res.json(saveState);
    } catch (error) {
      res.status(500).json({ message: "Failed to save state" });
    }
  });

  app.delete("/api/save-states/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSaveState(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Save state not found" });
      }
      res.json({ message: "Save state deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete save state" });
    }
  });

  // Game Notes
  app.get("/api/games/:gameId/notes", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: "userId is required" });
      }
      const notes = await storage.getGameNotes(req.params.gameId, userId);
      res.json(notes || { content: "" });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  app.post("/api/game-notes", async (req, res) => {
    try {
      const validatedData = insertGameNotesSchema.parse(req.body);
      const notes = await storage.createOrUpdateGameNotes(validatedData);
      res.json(notes);
    } catch (error) {
      res.status(500).json({ message: "Failed to save notes" });
    }
  });

  // Chat Messages
  app.get("/api/chat/:roomId", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const messages = await storage.getChatMessages(req.params.roomId, limit);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const validatedData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(validatedData);
      res.json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
