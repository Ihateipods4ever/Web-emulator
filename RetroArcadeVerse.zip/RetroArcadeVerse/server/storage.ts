import { type User, type InsertUser, type Console, type InsertConsole, type Game, type InsertGame, type SaveState, type InsertSaveState, type GameNotes, type InsertGameNotes, type ChatMessage, type InsertChatMessage, users, consoles, games, saveStates, gameNotes, chatMessages } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Consoles
  getConsoles(): Promise<Console[]>;
  getConsole(id: string): Promise<Console | undefined>;
  createConsole(console: InsertConsole): Promise<Console>;

  // Games
  getGamesByUser(userId: string): Promise<Game[]>;
  getGame(id: string): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  deleteGame(id: string): Promise<boolean>;

  // Save States
  getSaveStatesByGame(gameId: string): Promise<SaveState[]>;
  getSaveState(gameId: string, slotNumber: number): Promise<SaveState | undefined>;
  createOrUpdateSaveState(saveState: InsertSaveState): Promise<SaveState>;
  deleteSaveState(id: string): Promise<boolean>;

  // Game Notes
  getGameNotes(gameId: string, userId: string): Promise<GameNotes | undefined>;
  createOrUpdateGameNotes(notes: InsertGameNotes): Promise<GameNotes>;

  // Chat Messages
  getChatMessages(roomId: string, limit?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private consoles: Map<string, Console>;
  private games: Map<string, Game>;
  private saveStates: Map<string, SaveState>;
  private gameNotes: Map<string, GameNotes>;
  private chatMessages: Map<string, ChatMessage>;

  constructor() {
    this.users = new Map();
    this.consoles = new Map();
    this.games = new Map();
    this.saveStates = new Map();
    this.gameNotes = new Map();
    this.chatMessages = new Map();

    // Initialize default consoles
    this.initializeDefaultConsoles();
  }

  private initializeDefaultConsoles() {
    const defaultConsoles: InsertConsole[] = [
      {
        name: "nes",
        displayName: "Nintendo NES",
        emulatorCore: "jsnes",
        supportedFormats: [".nes"],
        isActive: true,
      },
      {
        name: "snes",
        displayName: "Super Nintendo",
        emulatorCore: "snes9x",
        supportedFormats: [".smc", ".sfc"],
        isActive: true,
      },
      {
        name: "gameboy",
        displayName: "Game Boy",
        emulatorCore: "gambatte",
        supportedFormats: [".gb", ".gbc"],
        isActive: true,
      },
      {
        name: "gba",
        displayName: "Game Boy Advance",
        emulatorCore: "mgba",
        supportedFormats: [".gba"],
        isActive: true,
      },
      {
        name: "genesis",
        displayName: "Sega Genesis",
        emulatorCore: "genesis-plus-gx",
        supportedFormats: [".md", ".bin", ".gen"],
        isActive: true,
      },
      {
        name: "n64",
        displayName: "Nintendo 64",
        emulatorCore: "mupen64plus",
        supportedFormats: [".z64", ".n64", ".v64"],
        isActive: true,
      },
      {
        name: "psx",
        displayName: "PlayStation",
        emulatorCore: "beetle-psx",
        supportedFormats: [".bin", ".cue", ".img", ".iso"],
        isActive: true,
      },
      {
        name: "arcade",
        displayName: "Arcade (MAME)",
        emulatorCore: "mame",
        supportedFormats: [".zip", ".7z"],
        isActive: true,
      },
      {
        name: "atari2600",
        displayName: "Atari 2600",
        emulatorCore: "stella",
        supportedFormats: [".a26", ".bin"],
        isActive: true,
      },
      {
        name: "pce",
        displayName: "PC Engine",
        emulatorCore: "beetle-pce",
        supportedFormats: [".pce", ".sgx"],
        isActive: true,
      },
    ];

    defaultConsoles.forEach(console => {
      this.createConsole(console);
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      isPremium: false,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  // Consoles
  async getConsoles(): Promise<Console[]> {
    return Array.from(this.consoles.values()).filter(console => console.isActive);
  }

  async getConsole(id: string): Promise<Console | undefined> {
    return this.consoles.get(id);
  }

  async createConsole(insertConsole: InsertConsole): Promise<Console> {
    const id = randomUUID();
    const console: Console = { ...insertConsole, id };
    this.consoles.set(id, console);
    return console;
  }

  // Games
  async getGamesByUser(userId: string): Promise<Game[]> {
    return Array.from(this.games.values()).filter(game => game.userId === userId);
  }

  async getGame(id: string): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = randomUUID();
    const game: Game = { 
      ...insertGame, 
      id,
      addedAt: new Date(),
      coverImage: insertGame.coverImage || null,
    };
    this.games.set(id, game);
    return game;
  }

  async deleteGame(id: string): Promise<boolean> {
    return this.games.delete(id);
  }

  // Save States
  async getSaveStatesByGame(gameId: string): Promise<SaveState[]> {
    return Array.from(this.saveStates.values()).filter(state => state.gameId === gameId);
  }

  async getSaveState(gameId: string, slotNumber: number): Promise<SaveState | undefined> {
    return Array.from(this.saveStates.values()).find(
      state => state.gameId === gameId && state.slotNumber === slotNumber
    );
  }

  async createOrUpdateSaveState(insertSaveState: InsertSaveState): Promise<SaveState> {
    const existing = await this.getSaveState(insertSaveState.gameId, insertSaveState.slotNumber);
    
    if (existing) {
      const updated: SaveState = {
        ...existing,
        stateData: insertSaveState.stateData,
        screenshot: insertSaveState.screenshot || null,
        createdAt: new Date(),
      };
      this.saveStates.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const saveState: SaveState = {
        ...insertSaveState,
        id,
        createdAt: new Date(),
        screenshot: insertSaveState.screenshot || null,
      };
      this.saveStates.set(id, saveState);
      return saveState;
    }
  }

  async deleteSaveState(id: string): Promise<boolean> {
    return this.saveStates.delete(id);
  }

  // Game Notes
  async getGameNotes(gameId: string, userId: string): Promise<GameNotes | undefined> {
    return Array.from(this.gameNotes.values()).find(
      notes => notes.gameId === gameId && notes.userId === userId
    );
  }

  async createOrUpdateGameNotes(insertNotes: InsertGameNotes): Promise<GameNotes> {
    const existing = await this.getGameNotes(insertNotes.gameId, insertNotes.userId);
    
    if (existing) {
      const updated: GameNotes = {
        ...existing,
        content: insertNotes.content,
        updatedAt: new Date(),
      };
      this.gameNotes.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const notes: GameNotes = {
        ...insertNotes,
        id,
        updatedAt: new Date(),
      };
      this.gameNotes.set(id, notes);
      return notes;
    }
  }

  // Chat Messages
  async getChatMessages(roomId: string, limit: number = 50): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.roomId === roomId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit)
      .reverse();
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
      roomId: insertMessage.roomId || null,
    };
    this.chatMessages.set(id, message);
    return message;
  }
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize default consoles if they don't exist
    this.initializeDefaultConsoles();
    // Initialize demo user
    this.initializeDemoUser();
  }

  private async initializeDefaultConsoles() {
    try {
      const existingConsoles = await db.select().from(consoles);
      
      if (existingConsoles.length === 0) {
        const defaultConsoles: InsertConsole[] = [
          {
            name: "nes",
            displayName: "Nintendo NES",
            emulatorCore: "jsnes",
            supportedFormats: [".nes"] as string[],
            isActive: true,
          },
          {
            name: "snes",
            displayName: "Super Nintendo",
            emulatorCore: "snes9x",
            supportedFormats: [".smc", ".sfc"] as string[],
            isActive: true,
          },
          {
            name: "gameboy",
            displayName: "Game Boy",
            emulatorCore: "gambatte",
            supportedFormats: [".gb"] as string[],
            isActive: true,
          },
          {
            name: "gbc",
            displayName: "Game Boy Color",
            emulatorCore: "gambatte",
            supportedFormats: [".gbc"] as string[],
            isActive: true,
          },
          {
            name: "gba",
            displayName: "Game Boy Advance",
            emulatorCore: "mgba",
            supportedFormats: [".gba"] as string[],
            isActive: true,
          },
          {
            name: "genesis",
            displayName: "Sega Genesis",
            emulatorCore: "genesis_plus_gx",
            supportedFormats: [".md", ".gen", ".bin"] as string[],
            isActive: true,
          },
          {
            name: "n64",
            displayName: "Nintendo 64",
            emulatorCore: "mupen64plus",
            supportedFormats: [".z64", ".n64", ".v64"] as string[],
            isActive: true,
          },
          {
            name: "playstation",
            displayName: "Sony PlayStation",
            emulatorCore: "beetle_psx",
            supportedFormats: [".cue", ".img", ".iso"] as string[],
            isActive: true,
          },
          {
            name: "arcade",
            displayName: "Arcade",
            emulatorCore: "mame",
            supportedFormats: [".zip", ".7z"] as string[],
            isActive: true,
          },
          {
            name: "atari2600",
            displayName: "Atari 2600",
            emulatorCore: "stella",
            supportedFormats: [".a26", ".bin"] as string[],
            isActive: true,
          },
          {
            name: "pcengine",
            displayName: "PC Engine",
            emulatorCore: "beetle_pce",
            supportedFormats: [".pce", ".sgx"] as string[],
            isActive: true,
          }
        ];

        await db.insert(consoles).values(defaultConsoles);
      }
    } catch (error) {
      console.error("Error initializing default consoles:", error);
    }
  }

  private async initializeDemoUser() {
    try {
      const existingUser = await this.getUser("demo-user-1");
      
      if (!existingUser) {
        await db.insert(users).values({
          id: "demo-user-1",
          username: "DemoPlayer",
          email: "demo@retroplay.com",
          password: "demo123", // In real app, this would be hashed
          isPremium: false,
        });
        console.log("Demo user created");
      }
    } catch (error) {
      console.error("Error initializing demo user:", error);
    }
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Consoles
  async getConsoles(): Promise<Console[]> {
    return await db.select().from(consoles).where(eq(consoles.isActive, true));
  }

  async getConsole(id: string): Promise<Console | undefined> {
    const [console] = await db.select().from(consoles).where(eq(consoles.id, id));
    return console || undefined;
  }

  async createConsole(insertConsole: InsertConsole): Promise<Console> {
    const [console] = await db.insert(consoles).values(insertConsole).returning();
    return console;
  }

  // Games
  async getGamesByUser(userId: string): Promise<Game[]> {
    return await db.select().from(games).where(eq(games.userId, userId)).orderBy(desc(games.addedAt));
  }

  async getGame(id: string): Promise<Game | undefined> {
    const [game] = await db.select().from(games).where(eq(games.id, id));
    return game || undefined;
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const [game] = await db.insert(games).values(insertGame).returning();
    return game;
  }

  async deleteGame(id: string): Promise<boolean> {
    const result = await db.delete(games).where(eq(games.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  // Save States
  async getSaveStatesByGame(gameId: string): Promise<SaveState[]> {
    return await db.select().from(saveStates).where(eq(saveStates.gameId, gameId)).orderBy(asc(saveStates.slotNumber));
  }

  async getSaveState(gameId: string, slotNumber: number): Promise<SaveState | undefined> {
    const [state] = await db.select().from(saveStates).where(
      and(eq(saveStates.gameId, gameId), eq(saveStates.slotNumber, slotNumber))
    );
    return state || undefined;
  }

  async createOrUpdateSaveState(insertSaveState: InsertSaveState): Promise<SaveState> {
    const existing = await this.getSaveState(insertSaveState.gameId, insertSaveState.slotNumber);
    
    if (existing) {
      const [updated] = await db.update(saveStates)
        .set({
          stateData: insertSaveState.stateData,
          screenshot: insertSaveState.screenshot,
          createdAt: new Date(),
        })
        .where(eq(saveStates.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(saveStates).values(insertSaveState).returning();
      return created;
    }
  }

  async deleteSaveState(id: string): Promise<boolean> {
    const result = await db.delete(saveStates).where(eq(saveStates.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  // Game Notes
  async getGameNotes(gameId: string, userId: string): Promise<GameNotes | undefined> {
    const [notes] = await db.select().from(gameNotes).where(
      and(eq(gameNotes.gameId, gameId), eq(gameNotes.userId, userId))
    );
    return notes || undefined;
  }

  async createOrUpdateGameNotes(insertNotes: InsertGameNotes): Promise<GameNotes> {
    const existing = await this.getGameNotes(insertNotes.gameId, insertNotes.userId);
    
    if (existing) {
      const [updated] = await db.update(gameNotes)
        .set({
          content: insertNotes.content,
          updatedAt: new Date(),
        })
        .where(eq(gameNotes.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(gameNotes).values(insertNotes).returning();
      return created;
    }
  }

  // Chat Messages
  async getChatMessages(roomId: string, limit: number = 50): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages)
      .where(eq(chatMessages.roomId, roomId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db.insert(chatMessages).values(insertMessage).returning();
    return message;
  }
}

export const storage = new DatabaseStorage();
