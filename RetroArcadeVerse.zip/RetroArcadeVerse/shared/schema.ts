import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  isPremium: boolean("is_premium").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const consoles = pgTable("consoles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  displayName: text("display_name").notNull(),
  emulatorCore: text("emulator_core").notNull(),
  supportedFormats: jsonb("supported_formats").$type<string[]>().notNull(),
  isActive: boolean("is_active").default(true),
});

export const games = pgTable("games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  consoleId: varchar("console_id").references(() => consoles.id).notNull(),
  title: text("title").notNull(),
  filename: text("filename").notNull(),
  fileSize: integer("file_size").notNull(),
  romData: text("rom_data").notNull(), // base64 encoded ROM data
  coverImage: text("cover_image"),
  addedAt: timestamp("added_at").defaultNow(),
});

export const saveStates = pgTable("save_states", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  slotNumber: integer("slot_number").notNull(),
  stateData: text("state_data").notNull(), // base64 encoded save state
  screenshot: text("screenshot"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const gameNotes = pgTable("game_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  username: text("username").notNull(),
  message: text("message").notNull(),
  roomId: text("room_id").default("global"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertConsoleSchema = createInsertSchema(consoles).omit({
  id: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  addedAt: true,
});

export const insertSaveStateSchema = createInsertSchema(saveStates).omit({
  id: true,
  createdAt: true,
});

export const insertGameNotesSchema = createInsertSchema(gameNotes).omit({
  id: true,
  updatedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Console = typeof consoles.$inferSelect;
export type InsertConsole = z.infer<typeof insertConsoleSchema>;

export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export type SaveState = typeof saveStates.$inferSelect;
export type InsertSaveState = z.infer<typeof insertSaveStateSchema>;

export type GameNotes = typeof gameNotes.$inferSelect;
export type InsertGameNotes = z.infer<typeof insertGameNotesSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
