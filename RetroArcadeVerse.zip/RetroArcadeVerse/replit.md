# RetroPlay Gaming Platform

## Overview

RetroPlay is a web-based retro gaming platform that allows users to upload, play, and manage classic console games through browser-based emulation. The application features a React frontend with a retro gaming aesthetic, an Express.js backend API, and PostgreSQL database storage. Users can upload ROM files, save game states, take notes, and participate in real-time chat while gaming.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with custom retro gaming theme including neon colors and pixel art aesthetics
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation schemas

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for CRUD operations
- **File Handling**: Multer middleware for ROM file uploads with in-memory storage
- **Development**: Hot reload with Vite integration in development mode

### Data Storage Architecture
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL hosting
- **Schema**: Relational design with tables for users, consoles, games, save states, game notes, and chat messages
- **File Storage**: ROM files and save states stored as base64-encoded text in database columns
- **Session Management**: PostgreSQL session store using connect-pg-simple

### Emulation System
- **Approach**: Browser-based emulation with mock implementation (placeholder for real emulator cores)
- **Canvas Rendering**: HTML5 Canvas for game display with retro pixel art simulation
- **Input Handling**: Keyboard controls with planned gamepad support
- **Save States**: Multiple save slots per game with screenshot thumbnails

### Real-time Features
- **Chat System**: Polling-based chat implementation for multiplayer rooms
- **Live Updates**: Regular query invalidation for real-time data synchronization
- **Game Sessions**: Shared gaming experiences with chat integration

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL client for Neon Database
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect support
- **drizzle-kit**: Database migration and schema management tools

### UI and Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives (dialog, dropdown, tooltip, etc.)
- **tailwindcss**: Utility-first CSS framework with custom retro gaming color palette
- **lucide-react**: Icon library for gaming and UI icons
- **class-variance-authority**: Utility for creating variant-based component APIs

### Development and Build Tools
- **vite**: Fast build tool with React plugin and development server
- **@replit/vite-plugin-runtime-error-modal**: Replit-specific error handling
- **@replit/vite-plugin-cartographer**: Replit development enhancement
- **esbuild**: Fast JavaScript bundler for production builds

### Form and Data Management
- **@tanstack/react-query**: Server state management with caching and synchronization
- **react-hook-form**: Performant form library with minimal re-renders
- **@hookform/resolvers**: Validation resolver for Zod integration
- **zod**: TypeScript-first schema validation

### File and Media Handling
- **multer**: Middleware for handling multipart/form-data file uploads
- **date-fns**: Date manipulation library for timestamps and formatting

### Session and Authentication Infrastructure
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **express-session**: Session middleware for user state management