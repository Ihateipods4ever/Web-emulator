import { useState } from "react";
import { Gamepad, Settings, Keyboard, Usb } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ControllerSettings() {
  const [player1Control, setPlayer1Control] = useState<"keyboard" | "gamepad">("keyboard");
  const [player2Control, setPlayer2Control] = useState<"keyboard" | "gamepad" | "disconnected">("disconnected");
  const { toast } = useToast();

  const handlePlayer1Toggle = () => {
    const newControl = player1Control === "keyboard" ? "gamepad" : "keyboard";
    setPlayer1Control(newControl);
    toast({
      title: "Player 1 Control",
      description: `Switched to ${newControl === "keyboard" ? "keyboard" : "gamepad"} controls`
    });
  };

  const handlePlayer2Toggle = () => {
    if (player2Control === "disconnected") {
      setPlayer2Control("keyboard");
      toast({
        title: "Player 2 Connected",
        description: "Player 2 now using keyboard controls"
      });
    } else {
      const newControl = player2Control === "keyboard" ? "gamepad" : "keyboard";
      setPlayer2Control(newControl);
      toast({
        title: "Player 2 Control",
        description: `Switched to ${newControl === "keyboard" ? "keyboard" : "gamepad"} controls`
      });
    }
  };

  const handleConfigure = () => {
    toast({
      title: "Controller Configuration",
      description: "Arrow keys: D-Pad | Z: A Button | X: B Button | Enter: Start | Space: Select"
    });
  };

  return (
    <div className="comic-border bg-gray-800 rounded-lg p-4">
      <h2 className="font-retro text-lg font-black text-hot-pink mb-3 flex items-center">
        <Gamepad className="mr-2" size={18} />
        CONTROLS
      </h2>
      
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="font-bold text-sm">Player 1:</span>
          <button 
            className="retro-button px-3 py-1 text-xs font-bold rounded flex items-center"
            onClick={handlePlayer1Toggle}
          >
            {player1Control === "keyboard" ? (
              <>
                <Keyboard className="mr-1" size={12} />
                KEYBOARD
              </>
            ) : (
              <>
                <Gamepad className="mr-1" size={12} />
                GAMEPAD
              </>
            )}
          </button>
        </div>
        <div className="flex justify-between items-center">
          <span className="font-bold text-sm">Player 2:</span>
          <button 
            className={`px-3 py-1 text-xs font-bold border-2 rounded flex items-center ${
              player2Control === "disconnected" 
                ? "bg-gray-600 border-gray-500 opacity-50" 
                : "retro-button"
            }`}
            onClick={handlePlayer2Toggle}
          >
            {player2Control === "disconnected" ? (
              <>
                <Usb className="mr-1" size={12} />
                DISCONNECTED
              </>
            ) : player2Control === "keyboard" ? (
              <>
                <Keyboard className="mr-1" size={12} />
                KEYBOARD
              </>
            ) : (
              <>
                <Gamepad className="mr-1" size={12} />
                GAMEPAD
              </>
            )}
          </button>
        </div>
        <button 
          className="w-full retro-button py-2 font-bold rounded text-sm"
          onClick={handleConfigure}
        >
          <Settings className="mr-2" size={14} />
          CONFIGURE
        </button>
      </div>
    </div>
  );
}
