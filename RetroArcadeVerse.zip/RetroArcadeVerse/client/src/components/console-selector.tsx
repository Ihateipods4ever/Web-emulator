import { Gamepad, Smartphone, Plus, Tv, Monitor, Zap } from "lucide-react";
import type { Console } from "@shared/schema";

interface ConsoleSelectorProps {
  consoles: Console[];
  selectedConsole: string | null;
  onConsoleSelect: (consoleId: string) => void;
}

export default function ConsoleSelector({ consoles, selectedConsole, onConsoleSelect }: ConsoleSelectorProps) {
  const getConsoleIcon = (consoleName: string) => {
    switch (consoleName.toLowerCase()) {
      case "gameboy":
      case "gba":
        return <Smartphone className="mr-2 text-neon" size={14} />;
      case "psx":
      case "n64":
        return <Monitor className="mr-2 text-purple" size={14} />;
      case "arcade":
        return <Zap className="mr-2 text-golden" size={14} />;
      case "atari2600":
        return <Tv className="mr-2 text-orange" size={14} />;
      default:
        return <Gamepad className="mr-2 text-hot-pink" size={14} />;
    }
  };

  const getConsoleColor = (consoleName: string) => {
    switch (consoleName.toLowerCase()) {
      case "nes": return "text-electric";
      case "snes": return "text-purple";
      case "gameboy": return "text-neon";
      case "gba": return "text-golden";
      case "genesis": return "text-hot-pink";
      case "n64": return "text-orange";
      case "psx": return "text-purple";
      case "arcade": return "text-golden";
      case "atari2600": return "text-orange";
      case "pce": return "text-electric";
      default: return "text-white";
    }
  };

  return (
    <div className="space-y-2 max-h-80 overflow-y-auto">
      {consoles.map((console) => (
        <button
          key={console.id}
          onClick={() => onConsoleSelect(console.id)}
          className={`w-full retro-button p-2 text-left font-bold rounded transition-all text-xs lg:text-sm ${
            selectedConsole === console.id ? 'bg-neon text-black scale-105' : ''
          }`}
        >
          <div className="flex items-center">
            {getConsoleIcon(console.name)}
            <span className={selectedConsole === console.id ? 'text-black' : getConsoleColor(console.name)}>
              {console.displayName}
            </span>
          </div>
        </button>
      ))}
      <button className="w-full retro-button p-2 text-left font-bold rounded text-xs lg:text-sm opacity-75 hover:opacity-100">
        <Plus className="mr-2 text-electric" size={14} />
        REQUEST CONSOLE
      </button>
    </div>
  );
}
