import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface VirtualGamepadProps {
  consoleType: string | null;
  isVisible: boolean;
  onKeyPress: (key: string, isPressed: boolean) => void;
}

interface GamepadLayout {
  dpad: boolean;
  actionButtons: Array<{ label: string; key: string; color?: string }>;
  shoulderButtons: Array<{ label: string; key: string; side: "left" | "right" }>;
  startSelect: Array<{ label: string; key: string }>;
  analogSticks?: boolean;
}

const CONSOLE_LAYOUTS: Record<string, GamepadLayout> = {
  "nintendo entertainment system": {
    dpad: true,
    actionButtons: [
      { label: "B", key: "KeyZ", color: "bg-red-600" },
      { label: "A", key: "KeyX", color: "bg-blue-600" }
    ],
    shoulderButtons: [],
    startSelect: [
      { label: "SELECT", key: "Space" },
      { label: "START", key: "Enter" }
    ]
  },
  "nes": {
    dpad: true,
    actionButtons: [
      { label: "B", key: "KeyZ", color: "bg-red-600" },
      { label: "A", key: "KeyX", color: "bg-blue-600" }
    ],
    shoulderButtons: [],
    startSelect: [
      { label: "SELECT", key: "Space" },
      { label: "START", key: "Enter" }
    ]
  },
  "super nintendo entertainment system": {
    dpad: true,
    actionButtons: [
      { label: "Y", key: "KeyA", color: "bg-green-600" },
      { label: "X", key: "KeyS", color: "bg-blue-600" },
      { label: "B", key: "KeyZ", color: "bg-yellow-600" },
      { label: "A", key: "KeyX", color: "bg-red-600" }
    ],
    shoulderButtons: [
      { label: "L", key: "KeyQ", side: "left" },
      { label: "R", key: "KeyW", side: "right" }
    ],
    startSelect: [
      { label: "SELECT", key: "Space" },
      { label: "START", key: "Enter" }
    ]
  },
  "snes": {
    dpad: true,
    actionButtons: [
      { label: "Y", key: "KeyA", color: "bg-green-600" },
      { label: "X", key: "KeyS", color: "bg-blue-600" },
      { label: "B", key: "KeyZ", color: "bg-yellow-600" },
      { label: "A", key: "KeyX", color: "bg-red-600" }
    ],
    shoulderButtons: [
      { label: "L", key: "KeyQ", side: "left" },
      { label: "R", key: "KeyW", side: "right" }
    ],
    startSelect: [
      { label: "SELECT", key: "Space" },
      { label: "START", key: "Enter" }
    ]
  },
  "game boy": {
    dpad: true,
    actionButtons: [
      { label: "B", key: "KeyZ", color: "bg-gray-600" },
      { label: "A", key: "KeyX", color: "bg-gray-600" }
    ],
    shoulderButtons: [],
    startSelect: [
      { label: "SELECT", key: "Space" },
      { label: "START", key: "Enter" }
    ]
  },
  "gameboy": {
    dpad: true,
    actionButtons: [
      { label: "B", key: "KeyZ", color: "bg-gray-600" },
      { label: "A", key: "KeyX", color: "bg-gray-600" }
    ],
    shoulderButtons: [],
    startSelect: [
      { label: "SELECT", key: "Space" },
      { label: "START", key: "Enter" }
    ]
  },
  "sega genesis": {
    dpad: true,
    actionButtons: [
      { label: "A", key: "KeyZ", color: "bg-red-600" },
      { label: "B", key: "KeyX", color: "bg-yellow-600" },
      { label: "C", key: "KeyC", color: "bg-blue-600" }
    ],
    shoulderButtons: [],
    startSelect: [
      { label: "START", key: "Enter" }
    ]
  },
  "genesis": {
    dpad: true,
    actionButtons: [
      { label: "A", key: "KeyZ", color: "bg-red-600" },
      { label: "B", key: "KeyX", color: "bg-yellow-600" },
      { label: "C", key: "KeyC", color: "bg-blue-600" }
    ],
    shoulderButtons: [],
    startSelect: [
      { label: "START", key: "Enter" }
    ]
  },
  "nintendo 64": {
    dpad: true,
    actionButtons: [
      { label: "B", key: "KeyZ", color: "bg-green-600" },
      { label: "A", key: "KeyX", color: "bg-blue-600" }
    ],
    shoulderButtons: [
      { label: "L", key: "KeyQ", side: "left" },
      { label: "R", key: "KeyW", side: "right" },
      { label: "Z", key: "KeyE", side: "right" }
    ],
    startSelect: [
      { label: "START", key: "Enter" }
    ],
    analogSticks: true
  },
  "n64": {
    dpad: true,
    actionButtons: [
      { label: "B", key: "KeyZ", color: "bg-green-600" },
      { label: "A", key: "KeyX", color: "bg-blue-600" }
    ],
    shoulderButtons: [
      { label: "L", key: "KeyQ", side: "left" },
      { label: "R", key: "KeyW", side: "right" },
      { label: "Z", key: "KeyE", side: "right" }
    ],
    startSelect: [
      { label: "START", key: "Enter" }
    ],
    analogSticks: true
  }
};

export default function VirtualGamepad({ consoleType, isVisible, onKeyPress }: VirtualGamepadProps) {
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set());

  const layout = consoleType ? CONSOLE_LAYOUTS[consoleType.toLowerCase()] : null;

  const handleKeyDown = useCallback((key: string) => {
    if (!pressedKeys.has(key)) {
      setPressedKeys(prev => new Set(prev).add(key));
      onKeyPress(key, true);
    }
  }, [pressedKeys, onKeyPress]);

  const handleKeyUp = useCallback((key: string) => {
    setPressedKeys(prev => {
      const newSet = new Set(prev);
      newSet.delete(key);
      return newSet;
    });
    onKeyPress(key, false);
  }, [onKeyPress]);

  // Handle touch events with proper touch tracking
  const handleTouchStart = useCallback((e: React.TouchEvent, key: string) => {
    e.preventDefault();
    handleKeyDown(key);
  }, [handleKeyDown]);

  const handleTouchEnd = useCallback((e: React.TouchEvent, key: string) => {
    e.preventDefault();
    handleKeyUp(key);
  }, [handleKeyUp]);

  if (!isVisible || !layout) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 bg-gray-900/95 backdrop-blur-sm border-t border-electric">
      <div className="flex justify-between items-center p-4 max-w-screen-lg mx-auto">
        
        {/* Left Side - D-Pad */}
        <div className="flex flex-col items-center space-y-2">
          {layout.dpad && (
            <div className="relative">
              <div className="grid grid-cols-3 gap-1 w-32 h-32">
                {/* Up */}
                <div className="col-start-2">
                  <Button
                    className={`w-10 h-10 retro-button ${pressedKeys.has('ArrowUp') ? 'bg-neon text-black' : ''}`}
                    onTouchStart={(e) => handleTouchStart(e, 'ArrowUp')}
                    onTouchEnd={(e) => handleTouchEnd(e, 'ArrowUp')}
                    onMouseDown={() => handleKeyDown('ArrowUp')}
                    onMouseUp={() => handleKeyUp('ArrowUp')}
                    onMouseLeave={() => handleKeyUp('ArrowUp')}
                  >
                    ↑
                  </Button>
                </div>
                
                {/* Left */}
                <div className="col-start-1 row-start-2">
                  <Button
                    className={`w-10 h-10 retro-button ${pressedKeys.has('ArrowLeft') ? 'bg-neon text-black' : ''}`}
                    onTouchStart={(e) => handleTouchStart(e, 'ArrowLeft')}
                    onTouchEnd={(e) => handleTouchEnd(e, 'ArrowLeft')}
                    onMouseDown={() => handleKeyDown('ArrowLeft')}
                    onMouseUp={() => handleKeyUp('ArrowLeft')}
                    onMouseLeave={() => handleKeyUp('ArrowLeft')}
                  >
                    ←
                  </Button>
                </div>
                
                {/* Right */}
                <div className="col-start-3 row-start-2">
                  <Button
                    className={`w-10 h-10 retro-button ${pressedKeys.has('ArrowRight') ? 'bg-neon text-black' : ''}`}
                    onTouchStart={(e) => handleTouchStart(e, 'ArrowRight')}
                    onTouchEnd={(e) => handleTouchEnd(e, 'ArrowRight')}
                    onMouseDown={() => handleKeyDown('ArrowRight')}
                    onMouseUp={() => handleKeyUp('ArrowRight')}
                    onMouseLeave={() => handleKeyUp('ArrowRight')}
                  >
                    →
                  </Button>
                </div>
                
                {/* Down */}
                <div className="col-start-2 row-start-3">
                  <Button
                    className={`w-10 h-10 retro-button ${pressedKeys.has('ArrowDown') ? 'bg-neon text-black' : ''}`}
                    onTouchStart={(e) => handleTouchStart(e, 'ArrowDown')}
                    onTouchEnd={(e) => handleTouchEnd(e, 'ArrowDown')}
                    onMouseDown={() => handleKeyDown('ArrowDown')}
                    onMouseUp={() => handleKeyUp('ArrowDown')}
                    onMouseLeave={() => handleKeyUp('ArrowDown')}
                  >
                    ↓
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Shoulder Buttons - Left */}
          <div className="flex space-x-2">
            {layout.shoulderButtons.filter(btn => btn.side === 'left').map((button) => (
              <Button
                key={button.key}
                className={`px-3 py-1 text-xs retro-button ${pressedKeys.has(button.key) ? 'bg-neon text-black' : ''}`}
                onTouchStart={(e) => handleTouchStart(e, button.key)}
                onTouchEnd={(e) => handleTouchEnd(e, button.key)}
                onMouseDown={() => handleKeyDown(button.key)}
                onMouseUp={() => handleKeyUp(button.key)}
                onMouseLeave={() => handleKeyUp(button.key)}
              >
                {button.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Center - Start/Select */}
        <div className="flex flex-col items-center space-y-2">
          <div className="flex space-x-4">
            {layout.startSelect.map((button) => (
              <Button
                key={button.key}
                className={`px-4 py-2 text-xs retro-button ${pressedKeys.has(button.key) ? 'bg-neon text-black' : ''}`}
                onTouchStart={(e) => handleTouchStart(e, button.key)}
                onTouchEnd={(e) => handleTouchEnd(e, button.key)}
                onMouseDown={() => handleKeyDown(button.key)}
                onMouseUp={() => handleKeyUp(button.key)}
                onMouseLeave={() => handleKeyUp(button.key)}
              >
                {button.label}
              </Button>
            ))}
          </div>
          
          {consoleType && (
            <div className="text-xs text-gray-400 font-mono uppercase text-center">
              {consoleType} Controls
            </div>
          )}
        </div>

        {/* Right Side - Action Buttons */}
        <div className="flex flex-col items-center space-y-2">
          {/* Action Buttons */}
          <div className="relative">
            {layout.actionButtons.length === 2 && (
              <div className="flex space-x-2">
                {layout.actionButtons.map((button) => (
                  <Button
                    key={button.key}
                    className={`w-12 h-12 rounded-full font-bold text-white ${button.color || 'bg-gray-600'} ${pressedKeys.has(button.key) ? 'brightness-150 scale-110' : ''} transition-all`}
                    onTouchStart={(e) => handleTouchStart(e, button.key)}
                    onTouchEnd={(e) => handleTouchEnd(e, button.key)}
                    onMouseDown={() => handleKeyDown(button.key)}
                    onMouseUp={() => handleKeyUp(button.key)}
                    onMouseLeave={() => handleKeyUp(button.key)}
                  >
                    {button.label}
                  </Button>
                ))}
              </div>
            )}
            
            {layout.actionButtons.length === 3 && (
              <div className="grid grid-cols-2 gap-2 w-28">
                <div className="col-span-2 flex justify-center">
                  <Button
                    className={`w-12 h-12 rounded-full font-bold text-white ${layout.actionButtons[2].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[2].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                    onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[2].key)}
                    onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[2].key)}
                    onMouseDown={() => handleKeyDown(layout.actionButtons[2].key)}
                    onMouseUp={() => handleKeyUp(layout.actionButtons[2].key)}
                    onMouseLeave={() => handleKeyUp(layout.actionButtons[2].key)}
                  >
                    {layout.actionButtons[2].label}
                  </Button>
                </div>
                <Button
                  className={`w-12 h-12 rounded-full font-bold text-white ${layout.actionButtons[0].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[0].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                  onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[0].key)}
                  onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[0].key)}
                  onMouseDown={() => handleKeyDown(layout.actionButtons[0].key)}
                  onMouseUp={() => handleKeyUp(layout.actionButtons[0].key)}
                  onMouseLeave={() => handleKeyUp(layout.actionButtons[0].key)}
                >
                  {layout.actionButtons[0].label}
                </Button>
                <Button
                  className={`w-12 h-12 rounded-full font-bold text-white ${layout.actionButtons[1].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[1].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                  onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[1].key)}
                  onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[1].key)}
                  onMouseDown={() => handleKeyDown(layout.actionButtons[1].key)}
                  onMouseUp={() => handleKeyUp(layout.actionButtons[1].key)}
                  onMouseLeave={() => handleKeyUp(layout.actionButtons[1].key)}
                >
                  {layout.actionButtons[1].label}
                </Button>
              </div>
            )}
            
            {layout.actionButtons.length === 4 && (
              <div className="grid grid-cols-3 gap-1 w-32 h-32">
                {/* Y */}
                <div className="col-start-2 row-start-1">
                  <Button
                    className={`w-10 h-10 rounded-full font-bold text-white ${layout.actionButtons[0].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[0].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                    onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[0].key)}
                    onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[0].key)}
                    onMouseDown={() => handleKeyDown(layout.actionButtons[0].key)}
                    onMouseUp={() => handleKeyUp(layout.actionButtons[0].key)}
                    onMouseLeave={() => handleKeyUp(layout.actionButtons[0].key)}
                  >
                    {layout.actionButtons[0].label}
                  </Button>
                </div>
                
                {/* X */}
                <div className="col-start-1 row-start-2">
                  <Button
                    className={`w-10 h-10 rounded-full font-bold text-white ${layout.actionButtons[1].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[1].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                    onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[1].key)}
                    onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[1].key)}
                    onMouseDown={() => handleKeyDown(layout.actionButtons[1].key)}
                    onMouseUp={() => handleKeyUp(layout.actionButtons[1].key)}
                    onMouseLeave={() => handleKeyUp(layout.actionButtons[1].key)}
                  >
                    {layout.actionButtons[1].label}
                  </Button>
                </div>
                
                {/* A */}
                <div className="col-start-3 row-start-2">
                  <Button
                    className={`w-10 h-10 rounded-full font-bold text-white ${layout.actionButtons[3].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[3].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                    onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[3].key)}
                    onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[3].key)}
                    onMouseDown={() => handleKeyDown(layout.actionButtons[3].key)}
                    onMouseUp={() => handleKeyUp(layout.actionButtons[3].key)}
                    onMouseLeave={() => handleKeyUp(layout.actionButtons[3].key)}
                  >
                    {layout.actionButtons[3].label}
                  </Button>
                </div>
                
                {/* B */}
                <div className="col-start-2 row-start-3">
                  <Button
                    className={`w-10 h-10 rounded-full font-bold text-white ${layout.actionButtons[2].color || 'bg-gray-600'} ${pressedKeys.has(layout.actionButtons[2].key) ? 'brightness-150 scale-110' : ''} transition-all`}
                    onTouchStart={(e) => handleTouchStart(e, layout.actionButtons[2].key)}
                    onTouchEnd={(e) => handleTouchEnd(e, layout.actionButtons[2].key)}
                    onMouseDown={() => handleKeyDown(layout.actionButtons[2].key)}
                    onMouseUp={() => handleKeyUp(layout.actionButtons[2].key)}
                    onMouseLeave={() => handleKeyUp(layout.actionButtons[2].key)}
                  >
                    {layout.actionButtons[2].label}
                  </Button>
                </div>
              </div>
            )}
          </div>
          
          {/* Shoulder Buttons - Right */}
          <div className="flex space-x-2">
            {layout.shoulderButtons.filter(btn => btn.side === 'right').map((button) => (
              <Button
                key={button.key}
                className={`px-3 py-1 text-xs retro-button ${pressedKeys.has(button.key) ? 'bg-neon text-black' : ''}`}
                onTouchStart={(e) => handleTouchStart(e, button.key)}
                onTouchEnd={(e) => handleTouchEnd(e, button.key)}
                onMouseDown={() => handleKeyDown(button.key)}
                onMouseUp={() => handleKeyUp(button.key)}
                onMouseLeave={() => handleKeyUp(button.key)}
              >
                {button.label}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}