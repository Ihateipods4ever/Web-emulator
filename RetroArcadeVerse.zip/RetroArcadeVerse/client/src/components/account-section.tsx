import { UserCircle } from "lucide-react";

export default function AccountSection() {
  return (
    <div className="comic-border bg-gray-800 rounded-lg p-4 opacity-75">
      <h2 className="font-retro text-xl font-black text-gray-400 mb-4 flex items-center">
        <UserCircle className="mr-2" size={20} />
        ACCOUNT
        <span className="ml-2 text-xs bg-gray-600 px-2 py-1 rounded">COMING SOON</span>
      </h2>
      
      <div className="space-y-3 text-gray-500">
        <div className="flex justify-between">
          <span>Plan:</span>
          <span className="font-bold">FREE TIER</span>
        </div>
        <div className="flex justify-between">
          <span>Games Played:</span>
          <span className="font-bold">0</span>
        </div>
        <div className="flex justify-between">
          <span>Achievements:</span>
          <span className="font-bold">0/100</span>
        </div>
        <button className="w-full bg-gray-600 py-2 font-bold rounded opacity-50 cursor-not-allowed">
          UPGRADE TO PREMIUM
        </button>
      </div>
    </div>
  );
}
