import { useState, useRef, useEffect, useCallback } from "react";
import { Play, Pause, OctagonMinus, RotateCcw, Expand, Gamepad2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { initializeEmulator } from "@/lib/emulator";
import { useIsMobile, useIsTouchDevice } from "@/hooks/use-mobile";
import VirtualGamepad from "./virtual-gamepad";

interface EmulatorCanvasProps {
  console: string | null;
  gameId: string | null;
  isPlaying: boolean;
  onPlayStateChange: (playing: boolean) => void;
}

interface Console {
  id: string;
  name: string;
  displayName: string;
}

export default function EmulatorCanvas({ console: consoleType, gameId, isPlaying, onPlayStateChange }: EmulatorCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [speed, setSpeed] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [emulatorInstance, setEmulatorInstance] = useState<any>(null);
  const [showVirtualGamepad, setShowVirtualGamepad] = useState(false);
  
  const isMobile = useIsMobile();
  const isTouchDevice = useIsTouchDevice();

  // Auto-show virtual gamepad on mobile devices when a game is loaded
  useEffect(() => {
    if ((isMobile || isTouchDevice) && gameId && !showVirtualGamepad) {
      setShowVirtualGamepad(true);
    }
  }, [isMobile, isTouchDevice, gameId, showVirtualGamepad]);

  const { data: gameData } = useQuery({
    queryKey: ["/api/games", gameId],
    enabled: !!gameId,
  });

  const { data: consoles } = useQuery({
    queryKey: ["/api/consoles"],
  });

  // Get the selected console's data
  const selectedConsoleData = Array.isArray(consoles) 
    ? consoles.find((c: Console) => c.id === consoleType)
    : null;
  const consoleName = selectedConsoleData?.name || null;

  useEffect(() => {
    if (gameData && consoleType && canvasRef.current && 
        typeof gameData === 'object' && gameData !== null && 
        'romData' in gameData && typeof gameData.romData === 'string') {
      
      const initEmulator = async () => {
        try {
          const emulator = await initializeEmulator(consoleType, canvasRef.current!, gameData.romData);
          setEmulatorInstance(emulator);
        } catch (error) {
          console.error('Failed to initialize emulator:', error);
          setEmulatorInstance(null);
        }
      };
      
      initEmulator();
      
      return () => {
        // Cleanup will be handled by the emulator instance itself
      };
    }
  }, [gameData, consoleType]);

  const handlePlay = () => {
    if (emulatorInstance) {
      emulatorInstance.play();
      onPlayStateChange(true);
    }
  };

  const handlePause = () => {
    if (emulatorInstance) {
      emulatorInstance.pause();
      onPlayStateChange(false);
    }
  };

  const handleStop = () => {
    if (emulatorInstance) {
      emulatorInstance.stop();
      onPlayStateChange(false);
    }
  };

  const handleReset = () => {
    if (emulatorInstance) {
      emulatorInstance.reset();
    }
  };

  const handleVirtualInput = useCallback((key: string, isPressed: boolean) => {
    if (emulatorInstance && emulatorInstance.handleInput) {
      emulatorInstance.handleInput(key, isPressed);
    }
    
    // Also trigger keyboard events for compatibility
    const event = new KeyboardEvent(isPressed ? 'keydown' : 'keyup', {
      key: key,
      code: key,
      bubbles: true
    });
    document.dispatchEvent(event);
  }, [emulatorInstance]);

  const toggleVirtualGamepad = () => {
    setShowVirtualGamepad(!showVirtualGamepad);
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenEnabled) {
        console.warn('Fullscreen is not supported on this device');
        return;
      }

      if (!isFullscreen && canvasRef.current) {
        await canvasRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else if (document.fullscreenElement) {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (error) {
      console.error('Fullscreen operation failed:', error);
      // Gracefully handle the error without breaking the app
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  return (
    <div className="aspect-video bg-gray-900 flex items-center justify-center relative">
      {!gameId || !consoleType ? (
        <div className="text-center">
          <div className="text-8xl text-gray-600 mb-4">📺</div>
          <p className="font-retro text-2xl font-bold text-gray-500">SELECT A CONSOLE</p>
          <p className="text-gray-400 mt-2">Choose a console and load a ROM to start playing</p>
        </div>
      ) : (
        <canvas
          ref={canvasRef}
          className="w-full h-full object-contain bg-black"
          width={256}
          height={240}
        />
      )}
      
      {/* Emulator Controls Overlay */}
      <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
        <div className="flex space-x-2">
          <button 
            className="retro-button p-2 rounded"
            onClick={handlePlay}
            disabled={!gameId || isPlaying}
          >
            <Play size={16} />
          </button>
          <button 
            className="retro-button p-2 rounded"
            onClick={handlePause}
            disabled={!gameId || !isPlaying}
          >
            <Pause size={16} />
          </button>
          <button 
            className="retro-button p-2 rounded"
            onClick={handleStop}
            disabled={!gameId}
          >
            <OctagonMinus size={16} />
          </button>
          <button 
            className="retro-button p-2 rounded"
            onClick={handleReset}
            disabled={!gameId}
          >
            <RotateCcw size={16} />
          </button>
        </div>
        
        <div className="flex space-x-2 items-center">
          <span className="font-mono text-xs">SPEED:</span>
          <button 
            className={`retro-button px-2 py-1 text-xs rounded ${speed === 1 ? 'bg-neon text-black' : ''}`}
            onClick={() => setSpeed(1)}
          >
            1X
          </button>
          <button 
            className={`retro-button px-2 py-1 text-xs rounded ${speed === 2 ? 'bg-neon text-black' : ''}`}
            onClick={() => setSpeed(2)}
          >
            2X
          </button>
          <button 
            className="retro-button px-2 py-1 text-xs rounded"
            onClick={toggleFullscreen}
            disabled={!gameId || !document.fullscreenEnabled}
            title={!document.fullscreenEnabled ? "Fullscreen not supported" : "Toggle fullscreen"}
          >
            <Expand size={12} />
          </button>
          
          {(isMobile || isTouchDevice) && (
            <button 
              className={`retro-button px-2 py-1 text-xs rounded ${showVirtualGamepad ? 'bg-neon text-black' : ''}`}
              onClick={toggleVirtualGamepad}
              disabled={!gameId}
              title="Toggle virtual gamepad"
            >
              <Gamepad2 size={12} />
            </button>
          )}
        </div>
      </div>
      
      {/* Virtual Gamepad */}
      <VirtualGamepad
        consoleType={consoleName}
        isVisible={showVirtualGamepad && !!gameId}
        onKeyPress={handleVirtualInput}
      />
    </div>
  );
}
