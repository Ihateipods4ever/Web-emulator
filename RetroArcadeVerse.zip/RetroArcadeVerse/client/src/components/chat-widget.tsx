import { useState, useEffect } from "react";
import { MessageSquareDashed, Send } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface ChatWidgetProps {
  roomId: string;
  userId: string;
  username: string;
}

export default function ChatWidget({ roomId, userId, username }: ChatWidgetProps) {
  const [message, setMessage] = useState("");

  const { data: messages = [] } = useQuery({
    queryKey: ["/api/chat", roomId],
    refetchInterval: 5000, // Poll every 5 seconds for new messages
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: { userId: string; username: string; message: string; roomId: string }) => {
      return apiRequest("POST", "/api/chat", messageData);
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat", roomId] });
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    sendMessageMutation.mutate({
      userId,
      username,
      message: message.trim(),
      roomId,
    });
  };

  const getUserColor = (username: string) => {
    const colors = ['text-electric', 'text-hot-pink', 'text-neon', 'text-golden', 'text-purple', 'text-orange'];
    const hash = username.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    return colors[hash % colors.length];
  };

  return (
    <div className="comic-border bg-gray-800 rounded-lg p-4">
      <h2 className="font-retro text-xl font-black text-orange mb-4 flex items-center justify-between">
        <span>
          <MessageSquareDashed className="mr-2" size={20} />
          CHAT
        </span>
        <span className="bg-neon text-black px-2 py-1 rounded text-xs font-bold">
          {Math.floor(Math.random() * 5) + 1} ONLINE
        </span>
      </h2>
      
      <div className="h-48 bg-gray-700 rounded p-3 overflow-y-auto mb-3 font-mono text-sm">
        <div className="space-y-2">
          {messages.length === 0 ? (
            <div className="text-gray-400 text-center py-8">
              <MessageSquareDashed className="mx-auto mb-2" size={32} />
              <p>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((msg: any) => (
              <div key={msg.id} className={getUserColor(msg.username)}>
                <strong>{msg.username}:</strong> {msg.message}
              </div>
            ))
          )}
        </div>
      </div>
      
      <form onSubmit={handleSendMessage} className="flex gap-2">
        <input
          type="text"
          placeholder="Type message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="flex-1 bg-gray-700 border-2 border-gray-600 rounded px-3 py-2 font-mono text-sm focus:border-electric focus:outline-none"
          disabled={sendMessageMutation.isPending}
        />
        <button 
          type="submit"
          className="retro-button px-3 py-2 rounded"
          disabled={sendMessageMutation.isPending || !message.trim()}
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
}
