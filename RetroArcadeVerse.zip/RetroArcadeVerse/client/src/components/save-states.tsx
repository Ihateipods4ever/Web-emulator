import { Save } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface SaveStatesProps {
  gameId: string | null;
  userId: string;
}

export default function SaveStates({ gameId, userId }: SaveStatesProps) {
  const { toast } = useToast();

  const { data: saveStates = [] } = useQuery({
    queryKey: ["/api/games", gameId, "save-states"],
    enabled: !!gameId,
  });

  const saveStateMutation = useMutation({
    mutationFn: async (data: { gameId: string; userId: string; slotNumber: number; stateData: string }) => {
      return apiRequest("POST", "/api/save-states", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games", gameId, "save-states"] });
      toast({
        title: "State Saved",
        description: "Game state saved successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save game state.",
        variant: "destructive",
      });
    },
  });

  const handleSaveState = (slotNumber: number) => {
    if (!gameId) {
      toast({
        title: "No Game Loaded",
        description: "Please load a game first.",
        variant: "destructive",
      });
      return;
    }

    // Mock save state data - in real implementation this would come from emulator
    const mockStateData = `save_state_${Date.now()}`;
    
    saveStateMutation.mutate({
      gameId,
      userId,
      slotNumber,
      stateData: mockStateData,
    });
  };

  const handleLoadState = (slotNumber: number) => {
    const saveState = saveStates.find((state: any) => state.slotNumber === slotNumber);
    if (!saveState) {
      toast({
        title: "No Save State",
        description: `Slot ${slotNumber} is empty.`,
        variant: "destructive",
      });
      return;
    }

    // Mock load state - in real implementation this would load into emulator
    toast({
      title: "State Loaded",
      description: `Loaded save state from slot ${slotNumber}!`,
    });
  };

  const getSlotStatus = (slotNumber: number) => {
    const saveState = saveStates.find((state: any) => state.slotNumber === slotNumber);
    return saveState ? "SAVED" : "EMPTY";
  };

  return (
    <div className="comic-border bg-gray-800 rounded-lg p-4">
      <h2 className="font-retro text-xl font-black text-neon mb-4 flex items-center">
        <Save className="mr-2" size={20} />
        SAVES
      </h2>
      
      <div className="grid grid-cols-2 gap-2">
        {[1, 2, 3, 4].map((slotNumber) => (
          <button
            key={slotNumber}
            className="retro-button p-2 text-xs font-bold rounded hover:bg-neon hover:text-black transition-colors"
            onClick={() => handleLoadState(slotNumber)}
            disabled={!gameId}
          >
            SLOT {slotNumber}<br />
            <span className={`${getSlotStatus(slotNumber) === 'SAVED' ? 'text-neon' : 'text-gray-300'}`}>
              {getSlotStatus(slotNumber)}
            </span>
          </button>
        ))}
      </div>
      
      <div className="mt-3 flex gap-2">
        <button 
          className="flex-1 retro-button py-2 text-xs font-bold rounded"
          onClick={() => handleSaveState(1)}
          disabled={!gameId || saveStateMutation.isPending}
        >
          SAVE
        </button>
        <button 
          className="flex-1 retro-button py-2 text-xs font-bold rounded"
          onClick={() => handleLoadState(1)}
          disabled={!gameId}
        >
          LOAD
        </button>
      </div>
    </div>
  );
}
