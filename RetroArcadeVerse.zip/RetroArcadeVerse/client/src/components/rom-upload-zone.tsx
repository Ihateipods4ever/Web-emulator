import { useState, useRef } from "react";
import { Upload, FolderOpen } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ROMUploadZoneProps {
  selectedConsole: string | null;
  userId: string;
  onGameUploaded: () => void;
}

export default function ROMUploadZone({ selectedConsole, userId, onGameUploaded }: ROMUploadZoneProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      console.log("Starting upload with FormData:", {
        romFile: formData.get("romFile"),
        userId: formData.get("userId"),
        consoleId: formData.get("consoleId"),
        title: formData.get("title")
      });
      const response = await apiRequest("POST", "/api/games", formData);
      return response.json();
    },
    onSuccess: (data) => {
      console.log("Upload successful:", data);
      toast({
        title: "ROM Uploaded",
        description: "Game has been added to your library!",
      });
      onGameUploaded();
    },
    onError: (error) => {
      console.error("Upload failed:", error);
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "Failed to upload ROM file. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFile = (file: File) => {
    if (!selectedConsole) {
      toast({
        title: "No Console Selected",
        description: "Please select a console first before uploading ROMs.",
        variant: "destructive",
      });
      return;
    }

    const title = file.name.replace(/\.[^/.]+$/, ""); // Remove file extension
    const formData = new FormData();
    formData.append("romFile", file);
    formData.append("userId", userId);
    formData.append("consoleId", selectedConsole);
    formData.append("title", title);

    uploadMutation.mutate(formData);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  return (
    <div
      className={`border-4 border-dashed rounded-lg p-12 text-center transition-all duration-300 cursor-pointer ${
        isDragOver 
          ? 'border-neon bg-gray-600' 
          : 'border-electric bg-gray-700 hover:bg-gray-600 hover:border-neon'
      }`}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOver(true);
      }}
      onDragLeave={(e) => {
        e.preventDefault();
        setIsDragOver(false);
      }}
      onDrop={handleDrop}
      onClick={() => fileInputRef.current?.click()}
    >
      <Upload className={`mx-auto mb-4 animate-pulse ${uploadMutation.isPending ? 'animate-spin' : ''}`} size={64} color="var(--electric)" />
      <p className="font-retro text-xl font-bold mb-2">
        {uploadMutation.isPending ? 'UPLOADING...' : 'DROP ROM FILES HERE'}
      </p>
      <p className="text-gray-300 mb-4">Supports: .nes, .smc, .gb, .gbc, .gba, .md, .z64, .bin, .cue, .iso, .zip, .7z, .a26, .pce files</p>
      <button 
        className="retro-button px-6 py-3 font-retro font-bold rounded"
        disabled={uploadMutation.isPending}
      >
        <FolderOpen className="inline mr-2" size={16} />
        BROWSE FILES
      </button>
      
      <input
        ref={fileInputRef}
        type="file"
        accept=".nes,.smc,.sfc,.gb,.gbc,.gba,.md,.bin,.rom,.z64,.n64,.v64,.cue,.img,.iso,.zip,.7z,.a26,.pce,.sgx,.gen"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}
