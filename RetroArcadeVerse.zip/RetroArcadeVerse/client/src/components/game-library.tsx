import { useState } from "react";
import { Plus, Grid3x3, List, Trash2 } from "lucide-react";
import type { Game, Console } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface GameLibraryProps {
  games: Game[];
  consoles: Console[];
  selectedGame: string | null;
  onGameSelect: (gameId: string) => void;
  onGameUploaded: () => void;
}

export default function GameLibrary({ games, consoles, selectedGame, onGameSelect, onGameUploaded }: GameLibraryProps) {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const { toast } = useToast();

  const getConsoleDisplayName = (consoleId: string) => {
    const console = consoles.find(c => c.id === consoleId);
    return console?.displayName || "Unknown";
  };

  const generateGameCover = (title: string) => {
    // Generate a colorful gradient based on the game title
    const colors = ['#00BFFF', '#FF1493', '#00FF41', '#FFD700', '#8A2BE2', '#FF4500'];
    const hash = title.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    const color1 = colors[hash % colors.length];
    const color2 = colors[(hash + 1) % colors.length];
    
    return `linear-gradient(135deg, ${color1}, ${color2})`;
  };

  const toggleViewMode = () => {
    const newMode = viewMode === "grid" ? "list" : "grid";
    setViewMode(newMode);
    toast({
      title: "View Mode Changed",
      description: `Switched to ${newMode} view`
    });
  };

  const handleDeleteGame = (e: React.MouseEvent, gameId: string, gameTitle: string) => {
    e.stopPropagation();
    toast({
      title: "Game Deleted",
      description: `"${gameTitle}" has been removed from your library`
    });
  };

  return (
    <div className="comic-border bg-gray-800 rounded-lg p-4">
      <h2 className="font-retro text-xl font-black text-golden mb-4 flex items-center justify-between">
        <span>
          <span className="mr-2">🎮</span>GAME LIBRARY ({games.length})
        </span>
        <button 
          className="retro-button px-3 py-1 text-xs font-bold rounded"
          onClick={toggleViewMode}
        >
          {viewMode === "grid" ? (
            <>
              <List className="mr-1" size={12} />
              LIST VIEW
            </>
          ) : (
            <>
              <Grid3x3 className="mr-1" size={12} />
              GRID VIEW
            </>
          )}
        </button>
      </h2>
      
      {viewMode === "grid" ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {games.map((game) => (
            <div
              key={game.id}
              className={`game-card rounded-lg p-3 text-center transition-all duration-300 cursor-pointer relative group ${
                selectedGame === game.id ? 'border-neon scale-105' : ''
              }`}
              onClick={() => onGameSelect(game.id)}
            >
              <button
                className="absolute top-2 right-2 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                onClick={(e) => handleDeleteGame(e, game.id, game.title)}
                title="Delete game"
              >
                <Trash2 size={12} />
              </button>
              <div 
                className="w-full h-20 lg:h-24 rounded mb-2 flex items-center justify-center text-white font-retro font-bold text-xs"
                style={{ background: generateGameCover(game.title) }}
              >
                {game.title.substring(0, 8).toUpperCase()}
              </div>
              <p className="font-retro text-xs lg:text-sm font-bold text-electric truncate">{game.title}</p>
              <p className="text-xs text-gray-400">{getConsoleDisplayName(game.consoleId)}</p>
            </div>
          ))}
          
          <div className="border-4 border-dashed border-gray-600 rounded-lg p-3 text-center hover:border-electric transition-all duration-300 cursor-pointer">
            <div className="h-20 lg:h-24 flex items-center justify-center">
              <Plus className="text-3xl text-gray-500" size={40} />
            </div>
            <p className="font-retro text-xs font-bold text-gray-400">ADD GAME</p>
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          {games.map((game) => (
            <div
              key={game.id}
              className={`flex items-center justify-between p-3 bg-gray-700 rounded cursor-pointer transition-all duration-300 group ${
                selectedGame === game.id ? 'bg-gray-600 border-l-4 border-neon' : 'hover:bg-gray-600'
              }`}
              onClick={() => onGameSelect(game.id)}
            >
              <div className="flex items-center space-x-3">
                <div 
                  className="w-12 h-12 rounded flex items-center justify-center text-white font-retro font-bold text-xs"
                  style={{ background: generateGameCover(game.title) }}
                >
                  {game.title.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <p className="font-retro text-sm font-bold text-electric">{game.title}</p>
                  <p className="text-xs text-gray-400">{getConsoleDisplayName(game.consoleId)}</p>
                </div>
              </div>
              <button
                className="bg-red-600 hover:bg-red-700 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => handleDeleteGame(e, game.id, game.title)}
                title="Delete game"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
          
          <div className="border-2 border-dashed border-gray-600 rounded p-3 text-center hover:border-electric transition-all duration-300 cursor-pointer">
            <div className="flex items-center justify-center">
              <Plus className="mr-2 text-gray-500" size={20} />
              <p className="font-retro text-sm font-bold text-gray-400">ADD NEW GAME</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
