import { useState, useEffect } from "react";
import { StickyNote, Save } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface NotesWidgetProps {
  gameId: string | null;
  userId: string;
}

export default function NotesWidget({ gameId, userId }: NotesWidgetProps) {
  const [content, setContent] = useState("");
  const { toast } = useToast();

  const { data: notes } = useQuery({
    queryKey: ["/api/games", gameId, "notes"],
    queryFn: async () => {
      if (!gameId) return null;
      const response = await fetch(`/api/games/${gameId}/notes?userId=${userId}`);
      return response.json();
    },
    enabled: !!gameId,
  });

  const saveNotesMutation = useMutation({
    mutationFn: async (noteData: { gameId: string; userId: string; content: string }) => {
      return apiRequest("POST", "/api/game-notes", noteData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/games", gameId, "notes"] });
      toast({
        title: "Notes Saved",
        description: "Your notes have been saved successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Save Failed",
        description: "Failed to save notes. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (notes?.content) {
      setContent(notes.content);
    } else {
      setContent("");
    }
  }, [notes]);

  const handleSave = () => {
    if (!gameId) {
      toast({
        title: "No Game Selected",
        description: "Please select a game to save notes for.",
        variant: "destructive",
      });
      return;
    }

    saveNotesMutation.mutate({
      gameId,
      userId,
      content,
    });
  };

  return (
    <div className="comic-border bg-gray-800 rounded-lg p-4">
      <h2 className="font-retro text-xl font-black text-purple mb-4 flex items-center">
        <StickyNote className="mr-2" size={20} />
        NOTES
      </h2>
      
      <textarea
        className="w-full h-32 bg-gray-700 border-2 border-gray-600 rounded p-3 font-mono text-sm resize-none focus:border-electric focus:outline-none transition-colors"
        placeholder={gameId ? "Write game codes, tips, or notes here..." : "Select a game to write notes..."}
        value={content}
        onChange={(e) => setContent(e.target.value)}
        disabled={!gameId}
      />
      
      <div className="mt-2 flex justify-between items-center">
        <span className="text-xs text-gray-400">
          {saveNotesMutation.isPending ? "Saving..." : "Auto-saved"}
        </span>
        <button 
          className="retro-button px-3 py-1 text-xs font-bold rounded"
          onClick={handleSave}
          disabled={!gameId || saveNotesMutation.isPending}
        >
          <Save className="mr-1" size={12} />
          SAVE
        </button>
      </div>
    </div>
  );
}
