export function validateROMFile(file: File, supportedFormats: string[]): boolean {
  const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
  return supportedFormats.includes(fileExtension);
}

export function getFileExtension(filename: string): string {
  return '.' + filename.split('.').pop()?.toLowerCase();
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function generateGameCover(title: string): string {
  // Generate a deterministic color scheme based on the game title
  const colors = [
    'linear-gradient(135deg, #00BFFF, #0080FF)',
    'linear-gradient(135deg, #FF1493, #CC1177)',
    'linear-gradient(135deg, #00FF41, #00CC33)',
    'linear-gradient(135deg, #FFD700, #CCAA00)',
    'linear-gradient(135deg, #8A2BE2, #6A1BAA)',
    'linear-gradient(135deg, #FF4500, #CC3300)',
  ];

  const hash = title.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

export async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove data URL prefix to get just the base64 data
      resolve(result.split(',')[1]);
    };
    reader.onerror = error => reject(error);
  });
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}
