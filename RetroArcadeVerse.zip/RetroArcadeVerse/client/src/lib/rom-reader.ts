// ROM file analysis and processing for real game files
// Provides utilities to read ROM headers and extract game information

export interface RomInfo {
  title: string;
  type: string;
  size: number;
  isValid: boolean;
  format: string;
  checksum?: string;
  region?: string;
  version?: string;
}

// Base64 to Uint8Array conversion
export function base64ToUint8Array(base64: string): Uint8Array {
  try {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  } catch (error) {
    console.error('Failed to decode base64 ROM data:', error);
    return new Uint8Array(0);
  }
}

// NES ROM analyzer
function analyzeNESRom(data: Uint8Array): RomInfo {
  if (data.length < 16) {
    return { title: 'Invalid ROM', type: 'NES', size: data.length, isValid: false, format: 'unknown' };
  }

  // Check for iNES header
  const header = data.slice(0, 16);
  const isINES = header[0] === 0x4E && header[1] === 0x45 && header[2] === 0x53 && header[3] === 0x1A;

  if (!isINES) {
    return { title: 'Unknown NES ROM', type: 'NES', size: data.length, isValid: false, format: 'raw' };
  }

  const prgRomSize = header[4] * 16384; // 16KB units
  const chrRomSize = header[5] * 8192;  // 8KB units
  const flags6 = header[6];
  const flags7 = header[7];

  const mapper = ((flags7 & 0xF0) | (flags6 >> 4));
  const mirroring = (flags6 & 1) ? 'vertical' : 'horizontal';

  return {
    title: `NES Game (Mapper ${mapper})`,
    type: 'NES',
    size: data.length,
    isValid: true,
    format: 'iNES',
    checksum: calculateChecksum(data),
    region: 'NTSC',
    version: `PRG:${prgRomSize/1024}KB CHR:${chrRomSize/1024}KB`
  };
}

// SNES ROM analyzer
function analyzeSNESRom(data: Uint8Array): RomInfo {
  if (data.length < 512) {
    return { title: 'Invalid ROM', type: 'SNES', size: data.length, isValid: false, format: 'unknown' };
  }

  // Try to find SNES header (usually at 0x7FC0 or 0xFFC0)
  const headerOffsets = [0x7FC0, 0xFFC0];
  let headerOffset = -1;
  let title = 'Unknown SNES Game';

  for (const offset of headerOffsets) {
    if (offset < data.length - 32) {
      // Check for valid title (printable ASCII)
      const titleBytes = data.slice(offset, offset + 21);
      let isValidTitle = true;
      for (let i = 0; i < titleBytes.length; i++) {
        if (titleBytes[i] !== 0x20 && (titleBytes[i] < 0x20 || titleBytes[i] > 0x7E)) {
          isValidTitle = false;
          break;
        }
      }
      if (isValidTitle) {
        headerOffset = offset;
        title = new TextDecoder().decode(titleBytes).trim() || 'SNES Game';
        break;
      }
    }
  }

  return {
    title,
    type: 'SNES',
    size: data.length,
    isValid: headerOffset !== -1,
    format: data.length % 1024 === 512 ? 'SMC' : 'SFC',
    checksum: calculateChecksum(data),
    region: 'NTSC',
    version: `${Math.floor(data.length / 1024)}KB`
  };
}

// Game Boy ROM analyzer
function analyzeGameBoyRom(data: Uint8Array): RomInfo {
  if (data.length < 0x150) {
    return { title: 'Invalid ROM', type: 'Game Boy', size: data.length, isValid: false, format: 'unknown' };
  }

  // Nintendo logo check
  const nintendoLogo = [
    0xCE, 0xED, 0x66, 0x66, 0xCC, 0x0D, 0x00, 0x0B, 0x03, 0x73, 0x00, 0x83, 0x00, 0x0C, 0x00, 0x0D,
    0x00, 0x08, 0x11, 0x1F, 0x88, 0x89, 0x00, 0x0E, 0xDC, 0xCC, 0x6E, 0xE6, 0xDD, 0xDD, 0xD9, 0x99,
    0xBB, 0xBB, 0x67, 0x63, 0x6E, 0x0E, 0xEC, 0xCC, 0xDD, 0xDC, 0x99, 0x9F, 0xBB, 0xB9, 0x33, 0x3E
  ];

  let isValidLogo = true;
  for (let i = 0; i < nintendoLogo.length; i++) {
    if (data[0x104 + i] !== nintendoLogo[i]) {
      isValidLogo = false;
      break;
    }
  }

  // Extract title
  const titleBytes = data.slice(0x134, 0x144);
  const title = new TextDecoder().decode(titleBytes).replace(/\0/g, '').trim() || 'Game Boy Game';

  // Cartridge type
  const cartridgeType = data[0x147];
  const romSize = data[0x148];
  const ramSize = data[0x149];

  const isGameBoyColor = data[0x143] === 0x80 || data[0x143] === 0xC0;

  return {
    title,
    type: isGameBoyColor ? 'Game Boy Color' : 'Game Boy',
    size: data.length,
    isValid: isValidLogo,
    format: 'GB',
    checksum: calculateChecksum(data),
    region: 'Universal',
    version: `ROM:${32 << romSize}KB RAM:${ramSize > 0 ? 8 << (ramSize - 1) : 0}KB`
  };
}

// Simple checksum calculation
function calculateChecksum(data: Uint8Array): string {
  let sum = 0;
  for (let i = 0; i < data.length; i++) {
    sum = (sum + data[i]) & 0xFFFFFFFF;
  }
  return sum.toString(16).toUpperCase().padStart(8, '0');
}

// Main ROM analysis function
export function analyzeROM(base64Data: string, consoleType: string): RomInfo {
  const data = base64ToUint8Array(base64Data);
  
  if (data.length === 0) {
    return { title: 'Invalid ROM Data', type: consoleType, size: 0, isValid: false, format: 'error' };
  }

  switch (consoleType.toLowerCase()) {
    case 'nes':
      return analyzeNESRom(data);
    case 'snes':
      return analyzeSNESRom(data);
    case 'gameboy':
    case 'game boy':
      return analyzeGameBoyRom(data);
    case 'gba':
    case 'game boy advance':
      // Basic GBA ROM analysis
      if (data.length < 0xC0) {
        return { title: 'Invalid GBA ROM', type: 'GBA', size: data.length, isValid: false, format: 'unknown' };
      }
      const gbaTitle = new TextDecoder().decode(data.slice(0xA0, 0xAC)).replace(/\0/g, '').trim() || 'GBA Game';
      return {
        title: gbaTitle,
        type: 'Game Boy Advance',
        size: data.length,
        isValid: data.length >= 0x8000, // Minimum GBA ROM size
        format: 'GBA',
        checksum: calculateChecksum(data),
        region: 'Universal',
        version: `${Math.floor(data.length / 1024)}KB`
      };
    case 'genesis':
    case 'mega drive':
      // Basic Genesis ROM analysis
      const genesisTitle = data.length > 0x150 ? 
        new TextDecoder().decode(data.slice(0x120, 0x150)).replace(/\0/g, '').trim() || 'Genesis Game' :
        'Genesis Game';
      return {
        title: genesisTitle,
        type: 'Genesis',
        size: data.length,
        isValid: data.length >= 0x8000,
        format: 'MD',
        checksum: calculateChecksum(data),
        region: 'NTSC',
        version: `${Math.floor(data.length / 1024)}KB`
      };
    default:
      return {
        title: `${consoleType} Game`,
        type: consoleType,
        size: data.length,
        isValid: data.length > 1024, // Assume valid if larger than 1KB
        format: 'unknown',
        checksum: calculateChecksum(data),
        region: 'Unknown',
        version: `${Math.floor(data.length / 1024)}KB`
      };
  }
}

// Validate ROM compatibility
export function validateROMCompatibility(romInfo: RomInfo, consoleType: string): boolean {
  if (!romInfo.isValid) return false;
  
  const normalizedConsole = consoleType.toLowerCase();
  const normalizedRomType = romInfo.type.toLowerCase();
  
  // Direct matches
  if (normalizedRomType.includes(normalizedConsole)) return true;
  
  // Cross-compatibility
  if (normalizedConsole === 'gameboy' && normalizedRomType.includes('game boy')) return true;
  if (normalizedConsole === 'nes' && romInfo.format === 'iNES') return true;
  if (normalizedConsole === 'snes' && (romInfo.format === 'SMC' || romInfo.format === 'SFC')) return true;
  
  return false;
}