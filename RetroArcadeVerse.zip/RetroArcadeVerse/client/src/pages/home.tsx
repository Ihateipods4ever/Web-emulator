import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Gamepad, Tv, Save, MessageSquareDashed, StickyNote, Users, Settings, Crown, User, Upload, Play, Pause, OctagonMinus, RotateCcw, ExpandIcon, Grid3x3Icon, HelpCircle, Bug, Heart } from "lucide-react";
import ConsoleSelector from "@/components/console-selector";
import ROMUploadZone from "@/components/rom-upload-zone";
import EmulatorCanvas from "@/components/emulator-canvas";
import GameLibrary from "@/components/game-library";
import NotesWidget from "@/components/notes-widget";
import ChatWidget from "@/components/chat-widget";
import SaveStates from "@/components/save-states";
import ControllerSettings from "@/components/controller-settings";
import AccountSection from "@/components/account-section";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [selectedConsole, setSelectedConsole] = useState<string | null>(null);
  const [selectedGame, setSelectedGame] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentUserId] = useState("demo-user-1"); // Mock user ID for demo
  const [showAccount, setShowAccount] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const { toast } = useToast();

  const { data: consoles } = useQuery({
    queryKey: ["/api/consoles"],
  });

  const { data: games, refetch: refetchGames } = useQuery({
    queryKey: ["/api/games"],
    queryFn: async () => {
      const response = await fetch(`/api/games?userId=${currentUserId}`);
      return response.json();
    },
  });

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header Navigation */}
      <header className="bg-black border-b-4 border-electric sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <nav className="flex items-center justify-between py-4">
            <div className="flex items-center space-x-4">
              <h1 className="font-retro text-3xl font-black text-electric animate-glow">
                <Gamepad className="inline mr-2" size={32} />
                RetroPlay
              </h1>
              <span className="font-mono text-xs text-neon bg-purple px-2 py-1 rounded">ULTIMATE</span>
            </div>
            
            <div className="flex items-center space-x-6">
              <button 
                className="retro-button px-4 py-2 font-retro text-sm font-bold rounded"
                onClick={() => {
                  setShowAccount(!showAccount);
                  toast({
                    title: "Account Panel",
                    description: showAccount ? "Account panel closed" : "Account panel opened"
                  });
                }}
              >
                <User className="inline mr-2" size={16} />
                ACCOUNT
              </button>
              <button 
                className="retro-button px-4 py-2 font-retro text-sm font-bold rounded"
                onClick={() => {
                  setShowSettings(!showSettings);
                  toast({
                    title: "Settings Panel",
                    description: showSettings ? "Settings panel closed" : "Settings panel opened"
                  });
                }}
              >
                <Settings className="inline mr-2" size={16} />
                SETTINGS
              </button>
              <button 
                className="retro-button px-4 py-2 font-retro text-sm font-bold rounded"
                onClick={() => {
                  toast({
                    title: "Premium Upgrade",
                    description: "Premium features coming soon! Get unlimited games, advanced save states, and exclusive console cores."
                  });
                }}
              >
                <Crown className="inline mr-2" size={16} />
                PREMIUM
              </button>
            </div>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 lg:gap-6">
          
          {/* Left Sidebar - Console Selection & Controls */}
          <div className="xl:col-span-3 space-y-4">
            
            {/* Console Selection */}
            <div className="comic-border bg-gray-800 rounded-lg p-4">
              <h2 className="font-retro text-lg font-black text-golden mb-3 flex items-center">
                <Tv className="mr-2" size={18} />
                CONSOLES
              </h2>
              <ConsoleSelector
                consoles={consoles || []}
                selectedConsole={selectedConsole}
                onConsoleSelect={setSelectedConsole}
              />
            </div>

            {/* Controller Settings */}
            <ControllerSettings />

            {/* Save States */}
            <SaveStates 
              gameId={selectedGame}
              userId={currentUserId}
            />

          </div>

          {/* Main Content Area */}
          <div className="xl:col-span-6 space-y-4 lg:space-y-6">
            
            {/* ROM Upload Area */}
            <div className="comic-border bg-gray-800 rounded-lg p-4 lg:p-6">
              <h2 className="font-retro text-xl lg:text-2xl font-black text-electric mb-4 text-center">
                <Upload className="inline mr-2" size={24} />
                DRAG & DROP ROM FILES
              </h2>
              <ROMUploadZone
                selectedConsole={selectedConsole}
                userId={currentUserId}
                onGameUploaded={refetchGames}
              />
            </div>

            {/* Emulator Viewport */}
            <div className="comic-border bg-black rounded-lg overflow-hidden">
              <EmulatorCanvas
                console={selectedConsole}
                gameId={selectedGame}
                isPlaying={isPlaying}
                onPlayStateChange={setIsPlaying}
              />
            </div>

            {/* Game Library */}
            <GameLibrary
              games={games || []}
              consoles={consoles || []}
              selectedGame={selectedGame}
              onGameSelect={setSelectedGame}
              onGameUploaded={refetchGames}
            />

          </div>

          {/* Right Sidebar - Chat & Notes */}
          <div className="xl:col-span-3 space-y-4">
            
            {/* Notes Widget */}
            <NotesWidget
              gameId={selectedGame}
              userId={currentUserId}
            />

            {/* Multiplayer Chat */}
            <ChatWidget
              roomId="global"
              userId={currentUserId}
              username="Player1"
            />

            {/* Online Players */}
            <div className="comic-border bg-gray-800 rounded-lg p-4">
              <h2 className="font-retro text-lg font-black text-golden mb-3 flex items-center">
                <Users className="mr-2" size={18} />
                PLAYERS
              </h2>
              <div className="space-y-2">
                {["Player1", "RetroKing", "GamerX"].map((player, index) => (
                  <div key={player} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 rounded-full mr-2 ${index === 0 ? 'bg-neon' : index === 1 ? 'bg-neon' : 'bg-orange'}`}></div>
                      <span className="font-bold text-xs lg:text-sm">{player}</span>
                    </div>
                    <button 
                      className="retro-button px-2 py-1 text-xs rounded"
                      onClick={() => {
                        toast({
                          title: `Invite Sent`,
                          description: `Game invitation sent to ${player}! They'll be notified to join your session.`
                        });
                      }}
                    >
                      INVITE
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Account Section (Mocked/Disconnected) */}
            <AccountSection />

          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black border-t-4 border-electric mt-12 py-6">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center items-center space-x-6 mb-4">
            <button 
              className="retro-button px-4 py-2 font-retro font-bold text-sm rounded"
              onClick={() => {
                toast({
                  title: "Help Center",
                  description: "Game controls: Arrow keys to move, Z/X for action buttons. Press F11 for fullscreen mode."
                });
              }}
            >
              <HelpCircle className="inline mr-2" size={16} />
              HELP
            </button>
            <button 
              className="retro-button px-4 py-2 font-retro font-bold text-sm rounded"
              onClick={() => {
                toast({
                  title: "Bug Report",
                  description: "Found a bug? Contact support with details about what happened and which console/game you were using."
                });
              }}
            >
              <Bug className="inline mr-2" size={16} />
              REPORT BUG
            </button>
            <button 
              className="retro-button px-4 py-2 font-retro font-bold text-sm rounded"
              onClick={() => {
                toast({
                  title: "Support RetroPlay",
                  description: "Love RetroPlay? Share with friends, leave a review, or upgrade to Premium to support development!"
                });
              }}
            >
              <Heart className="inline mr-2" size={16} />
              SUPPORT
            </button>
          </div>
          <p className="font-mono text-sm text-gray-400">
            © 2024 RetroPlay • The Ultimate Gaming Emulator Experience
          </p>
        </div>
      </footer>
    </div>
  );
}
